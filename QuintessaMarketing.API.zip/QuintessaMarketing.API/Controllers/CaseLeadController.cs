﻿using QuintessaMarketing.API;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Threading.Tasks;
using System.Web.Http;
using System.Web.Http.Description;

namespace QuintessaMarketing.API.Controllers
{
    /// <summary>
    /// Quintessa Case Leads
    /// </summary>
    [RoutePrefix("api/lead")]
    public class CaseLeadController : ApiController
    {
        public ICaseLeadService CaseLeadService { get; set; }

        public CaseLeadController()
        {
            CaseLeadService = new CaseLeadService();
        }

        /// <summary>
        /// Post Lead to Quintessa Marketing
        /// </summary>
        /// <remarks>Send Leads to Quintessa Marketing</remarks>
        /// <param name="caseLead">Lead Information</param>
        /// <returns>API Call Status</returns>
        /// <response code="200">OK</response>
        /// <response code="400">Bad Request</response>
        /// <response code="401">Unauthorized</response>
        /// <response code="500">Internal Server Error</response>
        [Route("submitlead")]
        [ResponseType(typeof(ContentActionResult<string>))]
        [HttpPost]
        public async Task<IHttpActionResult> Post(CaseLeadParameter caseLead)
        {
            var data = CaseLeadService.GetAPIKeyData(caseLead);

            if (data.Item1)
            {
                await CaseLeadService.ProcessCaseLead(caseLead, data.Item2);
                return new ContentActionResult<string>(HttpStatusCode.OK, "OK", null, Request);
            }

            return new ContentActionResult<string>(HttpStatusCode.Unauthorized, "Invalid api key", caseLead.API_Key, Request);
        }

        [Route("health")]
        [ResponseType(typeof(ContentActionResult<string>))]
        [HttpGet]
        public async Task<IHttpActionResult> CheckHealth()
        {
            return new ContentActionResult<string>(HttpStatusCode.OK, "OK", "OK", Request);
        }
    }
}

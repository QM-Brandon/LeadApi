﻿using QuintessaMarketing.API;
using System;
using System.Threading.Tasks;

public interface ICaseLeadService
{
    Task ProcessCaseLead(CaseLeadParameter caseLead, Guid affiliateId);
    Tuple<bool, Guid> GetAPIKeyData(CaseLeadParameter data);
}

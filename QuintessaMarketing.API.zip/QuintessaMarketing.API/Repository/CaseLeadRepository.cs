﻿using QuintessaMarketing.API;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Threading.Tasks;
using System.Web.Configuration;

public class CaseLeadRepository : ICaseLeadRepository
{
    private readonly string _connectionString;

    public CaseLeadRepository()
    {
        _connectionString = WebConfigurationManager.ConnectionStrings["MyConnection"].ConnectionString;
    }

    public async Task<string> AddCaseLead(CaseLeadData data, Guid affiliateId)
    {
        var caseid = string.Empty;
        var parameters = new List<SqlParameter>
        {
            new SqlParameter("@CampaignType", SqlDbType.VarChar) { Value = data.Source },
            new SqlParameter("@PotentialClientFullName", SqlDbType.VarChar) { Value = data.PotentialClientFullName },
            new SqlParameter("@PotentialClientFirstName", SqlDbType.VarChar) { Value = data.PotentialClientFirstName },
            new SqlParameter("@PotentialClientMiddleName", SqlDbType.VarChar) { Value = data.PotentialClientMiddleName },
            new SqlParameter("@PotentialClientLastName", SqlDbType.VarChar) { Value = data.PotentialClientLastName },
            new SqlParameter("@PotentialClientStreetAddress", SqlDbType.VarChar) { Value = data.PotentialClientStreetAddress },
            new SqlParameter("@PotentialClientCity", SqlDbType.VarChar) { Value = data.PotentialClientCity },
            new SqlParameter("@PotentialClientState", SqlDbType.VarChar) { Value = data.PotentialClientState },
            new SqlParameter("@PotentialClientZip", SqlDbType.VarChar) { Value = data.PotentialClientZip },
            new SqlParameter("@AccidentState", SqlDbType.VarChar) { Value = data.AccidentState },
            new SqlParameter("@PotentialClientPhoneNumber", SqlDbType.VarChar) { Value = data.PotentialClientPhoneNumber },
            new SqlParameter("@PotentialClientEmail", SqlDbType.VarChar) { Value = data.PotentialClientEmail },
            new SqlParameter("@CaseDescription", SqlDbType.VarChar) { Value = data.CaseDescription },
            new SqlParameter("@IncidentDate", SqlDbType.DateTime) { Value = data.ProcessedIncidentDate, IsNullable = true },
            new SqlParameter("@CaseType", SqlDbType.VarChar) { Value = data.CaseType },
            new SqlParameter("@AffiliateId", SqlDbType.UniqueIdentifier) { Value = affiliateId },
            new SqlParameter("@CaseIdOutput", SqlDbType.UniqueIdentifier,255, ParameterDirection.Output,false, 0, 0, null, DataRowVersion.Default, null)
        };

        using (var connection = new SqlConnection(_connectionString))
        {
            try
            {
                var command = new SqlCommand("QMCase_AddLead", connection)
                {
                    CommandType = CommandType.StoredProcedure,
                    CommandTimeout = 50
                };
                command.Parameters.AddRange(parameters.ToArray());
                connection.Open();
                await command.ExecuteNonQueryAsync();
                caseid = Convert.ToString(command.Parameters["@CaseIdOutput"].Value);
            }
            finally
            {
                connection.Close();
            }
        }

        return caseid;
    }

    public DataTable GetAffiliateWithApiKey(Guid apiKey)
    {
        using (var connection = new SqlConnection(_connectionString))
        {
            try
            {
                var sqlCommand = "Select TOP 1 * FROM qmAffiliate WHERE apikey = @API_Key";
                var command = new SqlCommand(sqlCommand, connection)
                {
                    CommandType = CommandType.Text,
                    CommandTimeout = 50
                };
                command.Parameters.Add(new SqlParameter() { ParameterName = "@API_Key", Value = apiKey, SqlDbType = SqlDbType.UniqueIdentifier });
                var dataTable = new DataTable();
                connection.Open();
                var dataAdapter = new SqlDataAdapter(command);
                dataAdapter.Fill(dataTable);
                dataAdapter.Dispose();
                return dataTable;
            }
            finally
            {
                connection.Close();
            }
        }
    }

    public async Task LogAPIInformationAsync(Guid logId, DateTime dateTime, string information)
    {
        using (var connection = new SqlConnection(_connectionString))
        {
            try
            {
                var sqlCommand = "INSERT INTO LOG (logid, datetime, message) VALUES (@logId, @dateTime, @message)";
                var command = new SqlCommand(sqlCommand, connection)
                {
                    CommandType = CommandType.Text,
                    CommandTimeout = 50
                };
                command.Parameters.Add(new SqlParameter() { ParameterName = "@logId", SqlDbType = SqlDbType.UniqueIdentifier, Value = logId });
                command.Parameters.Add(new SqlParameter() { ParameterName = "@dateTime", SqlDbType = SqlDbType.DateTime, Value = dateTime });
                command.Parameters.Add(new SqlParameter() { ParameterName = "@message", SqlDbType = SqlDbType.VarChar, Value = information });
                connection.Open();
                await command.ExecuteNonQueryAsync();
            }
            finally
            {
                connection.Close();
            }
        }
    }
}